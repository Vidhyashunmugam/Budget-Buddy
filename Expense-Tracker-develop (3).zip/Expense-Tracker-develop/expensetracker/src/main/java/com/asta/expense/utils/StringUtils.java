package com.asta.expense.utils;

import java.time.LocalDateTime;

public class StringUtils {
    public static String user = "vidh";
    public static LocalDateTime now = LocalDateTime.now();
}
